# RED THREAD — Agent Handoff Pack

This pack updates the portfolio direction to **React + Vite + TypeScript** and defines a curated asset/library vault.

## Important delivery note

This archive contains project specifications, source links, dependency guidance, asset records, licence notes and implementation instructions. It does **not** vendor or redistribute third-party repositories or media assets. This runtime could not reach GitHub to clone/download repositories. The agent should retrieve approved sources directly, verify their current contents and licences, and record commit hashes before incorporating code.

## Read order

1. `docs/DESIGN.md`
2. `docs/TYPOGRAPHY.md`
3. `docs/ARCHITECTURE.md`
4. `docs/DEPENDENCIES.md`
5. `asset-vault/ASSET_VAULT.md`
6. `asset-vault/LICENSING.md`
7. `asset-vault/manifests/sources.json`

## Non-negotiable design rules

- No random W-logo decorations.
- Use the user's supplied real portrait (`Wafiq.jpeg`) as the portrait source. Do not invent or alter identity.
- Japanese contemporary editorial + experimental art-book direction. Do not use superficial Japanese clichés.
- Every visual element and animation must have a purpose.
- The CRT gateway, editorial portfolio, puzzle experience and print résumé are separate experiences.
- Do not make the puzzle a gate to professional information.
- Do not install every listed library. Select only what the implementation actually needs.
- Do not copy third-party assets without checking per-asset licence and attribution requirements.
